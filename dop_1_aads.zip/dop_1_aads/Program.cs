﻿using System;
using System.Collections.Generic;

namespace dop_1_aads{
    public class Fight {
        public List<Fighter> l;
        public Fight(List<Fighter> f) {
            l = f;
        }
        public void Excerpt() {
            double[] e = new double[2] {0, 0};
            for (int i = 0; i < 2; i++) {
                if (l[i].DamagePerAttack > 0)
                    e[i] = Convert.ToDouble(l[(i + 1) % 2].Health) / Convert.ToDouble(l[i].DamagePerAttack);
                if (e[i] - Convert.ToInt32(e[i]) > 0)
                    e[i] += 1;
            }
            if (e[1] >= e[0])
                Console.WriteLine("Winner is {0}", l[0].Name);
            else
                Console.WriteLine("Winner is {0}", l[1].Name);
        }
    }
    public class Fighter {
        public string Name { get; private set;}
        public int Health { get; set;}
        public int DamagePerAttack { get; private set;}
        public Fighter (string name, int health, int damage) {
            this.Name = name;
            this.Health = health;
            this.DamagePerAttack = damage;
        }        
    }
    class Program{
        static void Main(string[] args){

            Fighter a = new Fighter("Jackson", 10, 5);
            Fighter b = new Fighter("Rod", 10, 4);

            List<Fighter> l = new List<Fighter> {a,b};
            Fight f = new Fight(l);
            f.Excerpt();
        }
    }
}
